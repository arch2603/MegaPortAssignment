1. Unzip the file to somewhere on your computer where you have full access
2. Create a new java with maven project
3. Import the folders you unzip at 1. inside the Java-Maven project you created
4. Navigate to your unzip folders, by opening up the folders, go to src/main/java/
5. Copy or Cut the folder from 4 to the new project created under the following path.
6. src/main/java
7. Copy the test folder from your unzip folders to you new project under the
   following path 
8. src/test/java
9. If your IDE complaints about the imports on the test files, make sure you incorporate
   the imports into your class path (note: I am using intelliJ so I right click on the word
   that is highlighted and click add to classpath)

Adding the Mockito to your dependencies:

1. Copy the following dependency to the pom.xml file of new java project
   <dependency>
   <groupId>org.mockito</groupId>
   <artifactId>mockito-core</artifactId>
   <version>4.3.1</version>
   </dependency>

2. Make sure it is wrapped within <dependencies></dependecies>


Adding Maven fail-safe plugin:

1. Ensure you include the maven-failsafe-plugin.jar file from the unzip folders to jar modules
2. For IntelliJ, click File the select Project Structure
3. Under Project Settings on the left Window, click Modules
4. Click the + sign and select the top option JARs or Directories 
5. Navigate where the JAR file above and select.
   
   