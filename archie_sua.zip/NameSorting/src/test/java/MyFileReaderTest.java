import megaport.MyFileReader;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.io.FileNotFoundException;
import static org.junit.jupiter.api.Assertions.*;

class MyFileReaderTest {
    MyFileReader fileReader = null;
    MyFileReader fileReaderNoPath = null;
    final String FILE_PATH = "C:\\file\\names-unsorted.txt";
    final String WRONG_FILE_PATH = "C:\\names-unsorted.txt";

    @BeforeEach
    void setUp() {
        fileReader = new MyFileReader(FILE_PATH);
        fileReaderNoPath = new MyFileReader(WRONG_FILE_PATH);
    }

    @Test
    @DisplayName("returns an empty arrayList")
    void getNames() {
        assertTrue(fileReader.getNames().isEmpty());

    }

    @Test
    @DisplayName("returns an array with names read from the file")
    void returnArrayWithNamesReadFromFile() throws FileNotFoundException {
        fileReader.readFile();
        Assertions.assertAll(
            () ->assertFalse(fileReader.getNames().isEmpty()),
            () -> assertNotNull(fileReader.getNames())
        );

    }

    @Test()
    @DisplayName("exception is thrown when a file is not found ")
    void readFile() {
        FileNotFoundException fileNotFoundException = Assertions.assertThrows(FileNotFoundException.class, () ->{
            fileReaderNoPath.readFile();
        }, "File could not be found");

        Assertions.assertEquals("C:\\names-unsorted.txt (The system cannot find the file specified)", fileNotFoundException.getMessage());
    }

}