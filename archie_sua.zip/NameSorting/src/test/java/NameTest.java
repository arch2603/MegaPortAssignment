import megaport.MyFileReader;
import megaport.Name;
import org.junit.jupiter.api.*;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class NameTest {

    Name _names = null;
    MyFileReader myFileReader = null;
    ArrayList<String> unsortedNames = null;
    ArrayList<String> sortedNames = null;
    boolean fileIsCreated = false;
    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    private final ByteArrayOutputStream errContent = new ByteArrayOutputStream();
    private final PrintStream originalOut = System.out;
    private final PrintStream originalErr = System.err;

    private final String FILE_PATH = "C:\\file\\names-unsorted.txt";
    private final String NEW_FILE_PATH = "C:\\file\\names-sorted.txt";
    private final String WRONG_FILE_PATH = "E:\\unsorted.txt";


    @BeforeEach
    void setup() throws IOException {
        unsortedNames = new ArrayList<>();
        myFileReader = new MyFileReader(FILE_PATH);
        myFileReader.readFile();
        unsortedNames = myFileReader.getNames();
        _names = new Name(unsortedNames, FILE_PATH);
        fileIsCreated = _names.createNewFile(NEW_FILE_PATH);
        sortedNames = _names.getSortedNames();

        System.setOut(new PrintStream(outContent));
        System.setErr(new PrintStream(errContent));
    }

    @AfterEach
    void restoreStreams()
    {
        System.setOut(originalOut);
        System.setErr(originalErr);
    }

    @Test
    @DisplayName("single name read from the file, sorted and write")
    void printSingleNameReadFromFile()
    {
        Name name = mock(Name.class);
        ArrayList<String> names = new ArrayList<>();
        names.add("BAKER, THEODORE");
        when(name.getUnsortedNames()).thenReturn(names);

        Assertions.assertAll(
                () -> assertEquals(1, names.size()),
                () -> assertEquals(names, name.getUnsortedNames()),
                () -> assertTrue(names.contains("BAKER, THEODORE"))
        );

    }

    @Test
    @DisplayName("print the names from the file in sorted order")
    void printNames()
    {
        ArrayList<String> sortedNames = _names.getUnsortedNames();
        Assertions.assertAll(
                () -> assertEquals("BAKER, THEODORE",sortedNames.get(0)),
                () -> assertEquals("KENT, MADISON", sortedNames.get(1)),
                () -> assertEquals("SMITH, ANDREW", sortedNames.get(2)),
                () -> assertEquals("SMITH, FREDRICK", sortedNames.get(3))
        );

    }

    @Test
    @DisplayName("test the file has been created or exists")
    void printFileNameAlreadyExist()
    {
       assertTrue(_names.getNewSortedFile().exists());
    }

    @Test
    @DisplayName("exception thrown when the path of the file being read does not exist")
    void exceptionThrownWhenPathDoesNotExistOrUnableToWriteTo()
    {
        ArrayList<String> _listNames = new ArrayList<>();
        MyFileReader myFileReader = new MyFileReader(WRONG_FILE_PATH);
        _listNames = myFileReader.getNames();
        Name names = new Name(_listNames, FILE_PATH);

        Exception exception = Assertions.assertThrows(IOException.class, () -> names.createNewFile(WRONG_FILE_PATH), "path input incorrect");

        String expectedMessage = "The device is not ready";
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));
        assertEquals(expectedMessage, actualMessage);

    }

    @Test
    @DisplayName("the final list of names should be sorted, fail when the names before is the same as the new list")
    void namesInArrayListBeforeAndAfterDifferent(){
        assertFalse(unsortedNames.equals(sortedNames));
    }
}