package megaport;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

public class Name {

    private ArrayList<String> unsortedNames;
    private ArrayList<String> sortedNames;
    private File newFileSorted;
    private String newSortedFilepath;
    private String unsortedFilepath;

    public Name(ArrayList<String> names, String unsortedFilepath) {
        sortedNames = new ArrayList<>();
        this.unsortedNames = names;
        this.unsortedFilepath = unsortedFilepath;
        this.sortNames();

    }

    public boolean createNewFile(String newFilePath) throws IOException
    {
        boolean isFileCreated = false;
        newFileSorted = new File(newFilePath);

        if (newFileSorted.createNewFile()) {
            System.out.println("File created");
            isFileCreated = false;
        }
        else {
            System.out.println("File already existed " + newFileSorted.getName());
            isFileCreated = true;
        }
        newSortedFilepath = newFileSorted.getAbsolutePath();

        return isFileCreated;
    }

    private void sortNames(){
        Collections.sort(this.unsortedNames);
    }

    public void printNames(){
        System.out.println("sort-names " + this.unsortedFilepath );
        this.writeNamesToFile();
        for (String name: this.unsortedNames) {
            System.out.println(name);
        }
        System.out.println("Finished: created " + this.newSortedFilepath);
    }

    private void writeNamesToFile(){
        try{
            FileWriter sortNamesFile = new FileWriter(this.newSortedFilepath);
            for(String name : this.unsortedNames)
            {
                sortNamesFile.write(name + "\n");
                this.sortedNames.add(name);
            }
            sortNamesFile.close();

        }catch (IOException io){
            System.out.println("Error writing to file");
            io.printStackTrace();
        }
    }

    public ArrayList<String> getUnsortedNames() {
        return unsortedNames;
    }

    public File getNewSortedFile()
    {
        return this.newFileSorted;
    }

    public ArrayList<String> getSortedNames() {
        return sortedNames;
    }


}
