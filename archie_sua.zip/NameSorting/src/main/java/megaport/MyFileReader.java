package megaport;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class MyFileReader {
    private File file;
    private Scanner scanner;
    private String filepath;
    ArrayList<String> names;


    public MyFileReader(String filepath){
        this.filepath = filepath;
        names = new ArrayList<>();
    }

    public void readFile() throws FileNotFoundException
    {
        file = new File(filepath);
        scanner = new Scanner(file);
        while (scanner.hasNextLine()){
            String person = scanner.nextLine();
            names.add(person);
        }
        scanner.close();

    }

    public ArrayList<String> getNames()
    {
        return this.names;
    }
}
