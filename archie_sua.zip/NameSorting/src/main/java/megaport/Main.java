package megaport;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args){
        String filePath, newFilePath;
        MyFileReader myFileReader;
        ArrayList<String> names;
        Name name;
        //scan the parameters passed to the main method
        if (args.length > 0)
        {
            filePath = args[0];
            newFilePath = args[1];
            myFileReader = new MyFileReader(filePath);
            try {
                myFileReader.readFile();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            names = myFileReader.getNames();
            name = new Name(names, filePath);
            try{
                name.createNewFile(newFilePath);
            }catch (IOException io){
                System.out.println("An error occurred");
                io.printStackTrace();
            }
            name.printNames();

        } else {
            System.out.println("Please enter the full path where the file is, e.g. C:\\folder\\filename.txt");
            Scanner scanner = new Scanner(System.in);
            filePath = scanner.nextLine();
            System.out.println("Please enter the full path where the new sorted file should be placed, " +
                    "e.g. C:\\folder\\filename.txt");
            newFilePath = scanner.nextLine();
            myFileReader = new MyFileReader(filePath);
            try {
                myFileReader.readFile();
            } catch (FileNotFoundException e) {
                System.out.println("File not found " + e.getMessage());
                e.printStackTrace();
            }
            names = myFileReader.getNames();
            name = new Name(names, filePath);
            try{
                name.createNewFile(newFilePath);
            }catch (IOException io){
                System.out.println("An error occurred");
                io.printStackTrace();
            }
            name.printNames();
        }
    }
}
